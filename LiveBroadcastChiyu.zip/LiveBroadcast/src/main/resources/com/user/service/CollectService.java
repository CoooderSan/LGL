package com.user.service;

public interface CollectService {
	public Integer updateUserCollect(String updateFlag,String userName,String collectInfo);
}
